'use client'

// Dashboard home: summarizes academy data and links to admin workflows.

import { useCallback, useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { CalendarDays, Eye, Newspaper, Trophy, Users } from 'lucide-react'
import { IconBadge } from '@/components/common/IconBadge'
import { createClient } from '@/lib/supabase/client'

interface DashboardStats {
  totalPlayers: number
  activePlayers: number
  upcomingEvents: number
  totalEvents: number
  recentNews: number
  totalNews: number
  activePlayerOfTheWeek: boolean
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalPlayers: 0,
    activePlayers: 0,
    upcomingEvents: 0,
    totalEvents: 0,
    recentNews: 0,
    totalNews: 0,
    activePlayerOfTheWeek: false,
  })
  const [loading, setLoading] = useState(true)
  const supabase = useMemo(() => createClient(), [])

  const fetchDashboardStats = useCallback(async () => {
    try {
      // Fetch players stats
      const { data: players, error: playersError } = await supabase
        .from('players')
        .select('status')

      if (playersError) throw playersError

      const totalPlayers = players?.length || 0
      const activePlayers = players?.filter(p => p.status === 'active').length || 0

      // Fetch events stats
      const { data: events, error: eventsError } = await supabase
        .from('events')
        .select('date')

      if (eventsError) throw eventsError

      const totalEvents = events?.length || 0
      const upcomingEvents = events?.filter(e => new Date(e.date) >= new Date()).length || 0

      // Fetch news stats
      const { data: news, error: newsError } = await supabase
        .from('news')
        .select('published_at')

      if (newsError) throw newsError

      const totalNews = news?.length || 0
      const recentNews = news?.filter(n =>
        n.published_at && new Date(n.published_at) >= new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      ).length || 0

      // Fetch player of the week stats
      const { data: potw, error: potwError } = await supabase
        .from('player_of_the_week')
        .select('is_active')
        .eq('is_active', true)
        .single()

      if (potwError && potwError.code !== 'PGRST116') throw potwError // PGRST116 is "no rows returned"

      const activePlayerOfTheWeek = !!potw

      setStats({
        totalPlayers,
        activePlayers,
        upcomingEvents,
        totalEvents,
        recentNews,
        totalNews,
        activePlayerOfTheWeek,
      })
    } catch (error) {
      console.error('Error fetching dashboard stats:', error)
    } finally {
      setLoading(false)
    }
  }, [supabase])

  useEffect(() => {
    fetchDashboardStats()
  }, [fetchDashboardStats])

  if (loading) {
    return (
      <div className="bg-gray-50 min-h-screen py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">Loading dashboard...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Coach Dashboard</h1>
            <p className="text-gray-600 mt-2">Manage your basketball academy operations</p>
          </div>
          <div className="text-sm text-gray-500">
            Last updated: {new Date().toLocaleDateString()}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-orange-500 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <IconBadge className="from-orange-400 to-red-500">
                  <Users className="h-6 w-6" aria-hidden="true" />
                </IconBadge>
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">Total Players</h3>
                <p className="text-3xl font-bold text-orange-600">{stats.totalPlayers}</p>
                <p className="text-sm text-gray-500">{stats.activePlayers} active</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <IconBadge className="from-blue-500 to-purple-600">
                  <CalendarDays className="h-6 w-6" aria-hidden="true" />
                </IconBadge>
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">Upcoming Events</h3>
                <p className="text-3xl font-bold text-blue-600">{stats.upcomingEvents}</p>
                <p className="text-sm text-gray-500">{stats.totalEvents} total events</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <IconBadge className="from-green-500 to-teal-600">
                  <Newspaper className="h-6 w-6" aria-hidden="true" />
                </IconBadge>
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">Recent News</h3>
                <p className="text-3xl font-bold text-green-600">{stats.recentNews}</p>
                <p className="text-sm text-gray-500">{stats.totalNews} total articles</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500 hover:shadow-xl transition-all duration-300 md:col-span-3">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <IconBadge className="from-yellow-400 to-orange-500">
                  <Trophy className="h-6 w-6" aria-hidden="true" />
                </IconBadge>
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">Player of the Week</h3>
                <p className="text-3xl font-bold text-yellow-600">
                  {stats.activePlayerOfTheWeek ? 'Active' : 'Not Set'}
                </p>
                <p className="text-sm text-gray-500">
                  {stats.activePlayerOfTheWeek ? 'Currently featuring a player' : 'Set a player to feature this week'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Link
                href="/dashboard/players"
                className="flex items-center p-4 bg-gradient-to-r from-orange-50 to-red-50 rounded-lg hover:from-orange-100 hover:to-red-100 transition-all duration-300 border border-orange-200"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-red-500 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-white font-bold">+</span>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Add Player</div>
                  <div className="text-sm text-gray-600">Create new player profile</div>
                </div>
              </Link>

              <Link
                href="/dashboard/events"
                className="flex items-center p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg hover:from-blue-100 hover:to-purple-100 transition-all duration-300 border border-blue-200"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mr-3">
                  <CalendarDays className="h-5 w-5 text-white" aria-hidden="true" /></div><div><div className="font-semibold text-gray-900">Manage Events</div>
                  <div className="text-sm text-gray-600">Schedule training & games</div>
                </div>
              </Link>

              <Link
                href="/dashboard/news"
                className="flex items-center p-4 bg-gradient-to-r from-green-50 to-teal-50 rounded-lg hover:from-green-100 hover:to-teal-100 transition-all duration-300 border border-green-200"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-teal-600 rounded-lg flex items-center justify-center mr-3">
                  <Newspaper className="h-5 w-5 text-white" aria-hidden="true" /></div><div><div className="font-semibold text-gray-900">Publish News</div>
                  <div className="text-sm text-gray-600">Share academy updates</div>
                </div>
              </Link>

              <Link
                href="/dashboard/player-of-the-week"
                className="flex items-center p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg hover:from-yellow-100 hover:to-orange-100 transition-all duration-300 border border-yellow-200"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center mr-3">
                  <Trophy className="h-5 w-5 text-white" aria-hidden="true" /></div><div><div className="font-semibold text-gray-900">Player of the Week</div>
                  <div className="text-sm text-gray-600">Feature standout players</div>
                </div>
              </Link>

              <Link
                href="/players"
                className="flex items-center p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg hover:from-purple-100 hover:to-pink-100 transition-all duration-300 border border-purple-200"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center mr-3">
                  <Eye className="h-5 w-5 text-white" aria-hidden="true" /></div><div><div className="font-semibold text-gray-900">View Public Site</div>
                  <div className="text-sm text-gray-600">See how it looks</div>
                </div>
              </Link>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Academy Overview</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">Active Players</span>
                <span className="text-lg font-bold text-orange-600">{stats.activePlayers}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">This Month's Events</span>
                <span className="text-lg font-bold text-blue-600">{stats.upcomingEvents}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">Published Articles</span>
                <span className="text-lg font-bold text-green-600">{stats.totalNews}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">Player Growth Rate</span>
                <span className="text-lg font-bold text-purple-600">
                  {stats.totalPlayers > 0 ? '+' + Math.round((stats.activePlayers / stats.totalPlayers) * 100) + '%' : '0%'}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-gradient-to-r from-blue-900 via-purple-900 to-blue-900 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold mb-2">Coach's Corner</h3>
              <p className="text-blue-100">
                "Champions aren't made in the gyms. Champions are made from something they have deep inside them - a desire, a dream, a vision."
              </p>
              <p className="text-orange-300 text-sm mt-2">- Muhammad Ali</p>
            </div>
            <Trophy className="h-16 w-16 opacity-20" aria-hidden="true" />
          </div>
        </div>
      </div>
    </div>
  )
}


